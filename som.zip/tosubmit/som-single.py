# som.py
# Implements a self-organizing map to cluster countries based on world development
# indicators.
#---------------------------------------------------------------------------------------
# CS324 Data Mining Final Project (Spring 2017)
# Yuan Shen Li and Il Shan Ng
# May 20, 2017

import numpy as np
import scipy.spatial.distance as sp
import argparse
import collections as cl
import pickle

class SOM_Single():
    """
    Self-organizing map, online version (training with single data point per iteration)
    """
    def __init__(self, J, K, inputs, init, dist_func, neighborhood_func, iterations):
        """
	Store class variables.
	"""
        self.inputs = inputs
        self.J = J
        self.K = K
        self.init = init
        self.dist_func = dist_func
        self.neighborhood_func = neighborhood_func
        self.M = []
        self.max_iterations = iterations
        self.adjustments = []

        # learning rate
        self.learningRate_init = 1
        self.learningRate_decayfactor = 5000
        self.learningRate = self.learningRate_init

        # radius/sigma of step/Gaussian neighborhood function
        self.sigma_init = max(J,K)/2
        self.sigma = self.sigma_init
        self.sigma_decayfactor = 10000
        self.sigma_floor = 0.5

    def initialize(self):
        """
	Takes in six parameters
	    - the initialization method 'init'
	    - input data
	and sets M to a (J*K x F) array storing the initialized models.
	"""
        F = len(self.inputs[0])
        
        # create 3D array storing initial models
        #np.random.seed(1)
        if self.init=='random':
            min_val = np.nanmin(self.inputs)
            max_val = np.nanmax(self.inputs)
            self.M = np.random.uniform(min_val, max_val, size=(self.J*self.K, F))
            self.M = np.array(self.M)
        if self.init=="linear":
            #Apply PCA to get pricipal components
            covmat = np.cov(self.inputs.T)
            eigvals,eigvecs = np.linalg.eig(covmat)
            v1 = eigvecs[0]
            v2 = eigvecs[1]

            # uniformly initialize models within 3 sigma using the 2 principal components
            step_j = 6./self.J
            step_k = 6./self.K

            self.M = np.array([[0. for i in range(len(self.inputs[0]))] for j in range (self.J*self.K)])
            for j in range(self.J):
                for k in range(self.K):
                    self.M[j*self.K + k] = (-3. + j*step_j) * v1 + (-3. + k*step_k) * v2
		    
    def competitive_step(self, pt):
        """
        Implements the competitive step of SOM training. Takes in 
            - a training point

        Returns index of winning neuron
        """
        pt = [pt]
        # create a distance matrix between inputs and models
        distance_matrix = sp.cdist(pt, self.M, self.dist_func)

        # find the index of the winner model
        winner = np.nanargmin(distance_matrix, axis=1)

        return winner[0]
        
    def adaptive_step(self, winner, pt):
        """
        Implements the adaptive step of SOM training. Takes in index of winner neuron and training pt
        Updates model M and returns error (change in model)
        """
        # compute topo distance to winner
        wJ = int(winner/self.K); wK = winner % self.K

        # construct a list of sq topo dist
        topoPos = [[int(i/self.K),i % self.K] for i in range(len(self.M))]
        sqTopoDist = np.square(sp.cdist([[wJ,wK]],topoPos,"euclidean")).T

        # construct "t matrix" based on neighborhood function
        if self.neighborhood_func == "gaussian":
            tMatrix = np.exp(-1 * sqTopoDist / (2* self.sigma**2))
        elif self.neighborhood_func == "step":
            tMatrix = np.array([[int(sqTopoDist[i] < self.sigma**2)] for i in range(len(sqTopoDist))])
        else:
            print("Neighborhood function not recognized. Quitting...")
            return

        # construct pt - self.M
        diffMatrix = pt - self.M
        # construct delta
        deltaMatrix = self.learningRate * diffMatrix * tMatrix
        # update M with delta
        self.M += deltaMatrix
        
        error = np.sum(deltaMatrix)

        return error

    def train(self):
        """
        Trains the SOM with input data
        Returns models M after training
        """
        for iterations in range(self.max_iterations):
            # pick a random input 
            randindex = np.random.randint(low=0,high=len(self.inputs))
            pt = self.inputs[randindex]

            # perform the competitive, then adaptive step
            winner = self.competitive_step(pt)
            error = self.adaptive_step(winner, pt)

            # keep track of error for convergence plot
            self.adjustments.append(error)

            # report on progess in command line
            if not iterations % 100:
                print("Iteration", iterations," with adjustment", error)
                
            # reduce sigma over iterations
            if self.neighborhood_func == "gaussian":
                self.sigma = max(self.sigma_floor, self.sigma_init * np.exp(-1 * iterations/self.sigma_decayfactor))
            # return learning rate over iterations
            self.learningRate = self.learningRate_init * np.exp(-1 * iterations/self.learningRate_decayfactor)

        return self.M

def read_data_WDI():
    """
    Reads in preprocessed WDI data. Writes country and country codes to file for analysis purposes.
    """
    #read in country names
    countries = np.genfromtxt("indicators_cleaned_complete.txt", delimiter='\t',usecols=0, dtype=str, skip_header=1)
    #read in country codes
    codes = np.genfromtxt("indicators_cleaned_complete.txt", delimiter='\t',usecols=1, dtype=str, skip_header=1)
    # read in indicators
    indicators = np.genfromtxt("indicators_cleaned_complete.txt", delimiter='\t',usecols=range(2,102), dtype=float, skip_header=1)

    # write countries to file
    f = open("countries.txt","w")
    for country in countries:
        f.write(country)
        f.write('\n')
    f.close()

    # write country codes to file
    f = open("codes.txt","w")
    for code in codes:
        f.write(code)
        f.write('\n')
    f.close()

    return (indicators)

    
def normalize_features(indicators):
    """
    Normalizes the data for each indicator over all countries.
    """
    # subtract column-wise mean and divide by column-wise standard error
    return((indicators-np.nanmean(indicators, axis=0))/np.nanstd(indicators, axis=0))


def main():
    # obtain command line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('J', type=int, 
                        help='Integer number representing the width of the map.')
    parser.add_argument('K', type=int, 
                        help='Integer number representing the height of the map.')
    parser.add_argument('init', type=str,
                        help='String representing the initialization method to use')
    parser.add_argument('dist_func', type=str,
                        help='String representing the distance function to use')
    parser.add_argument('neighborhood_func', type=str,
                        help='String representing the neighborhood function to use')
    parser.add_argument('iterations', type=int,
                        help='Number of iterations to run')
    flags, unparsed = parser.parse_known_args()

    # read in and normalize dataset
    indicators = read_data_WDI()
    inputs = normalize_features(indicators)

    # initialize SOM 
    som = SOM_Single(J=flags.J, K=flags.K, inputs=inputs, init=flags.init, dist_func=flags.dist_func,
                     neighborhood_func=flags.neighborhood_func, iterations=flags.iterations)
    som.initialize()

    # train SOM
    final_model = som.train()

    # compute winner for each data point (to make plot)
    distance_matrix = sp.cdist(inputs, final_model, flags.dist_func)
    winners = np.nanargmin(distance_matrix, axis=1)
    np.savetxt("winners_WDI.txt",winners)

    # save adjustments over iterations (for convergence plot)
    np.savetxt("adjustments_WDI.txt",som.adjustments)

    # pickle final model for posterity
    pickle.dump(final_model,open("model_WDI.p","wb"))

if __name__ == '__main__':
    main()
