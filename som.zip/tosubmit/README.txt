# CS324 Data Mining (Spring 2017)
# Final Project: SOM
# Yuan Shen Li, Il Shan Ng

There are four other files in this folder. All Python files run in Python3. 

1) som-single.py: This is the main SOM algorithm. It takes the following positional arguments:
   - J		       	      	   : y dimension of the map (J*K > 10000 takes a long time)
   - K 		  		   : x dimension of the map 
   - init	      		   : Initialization method. Choose either 'random' or 'linear'
   - dist_func	    		   : Distance function. Use 'euclidean'.
   - neighborhood_func		   : Neighborhood function. Choose either 'gaussian' or 'step'
   - iterations			   : Number of iterations to run. Recommended is 20000

2) visualize.py: This is the file to visualize the SOM. Run this after running som-single.py. It takes the following positional arguments:
   - J		      	     	   : x dimension of the SOM
   - K				   : y dimension of the SOM

3) visualize.nb: Mathematica notebook to actually plot the U-matrix. After running visualize.py, switch to this notebook and evaluate all cells. Remember to change the J and K values correspondingly in the notebook.
4) indicators_cleaned_complete.txt: This is our WDI dataset. Check report for more details.

   

   
